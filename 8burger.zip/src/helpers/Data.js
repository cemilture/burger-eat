import React from 'react';
import BurgerImage from '../assets/burger.jpg';

export const Data = [
  {
    name: 'Efso Burger',
    image: BurgerImage,
    content: '150 gr kasap Burger,Patates,Turşu',
    price: 250,
  },
  {
    name: 'Efso Burger',
    image: BurgerImage,
    content: '150 gr kasap Burger,Patates,Turşu',
    price: 250,
  },
  {
    name: 'Efso Burger',
    image: BurgerImage,
    content: '150 gr kasap Burger,Patates,Turşu',
    price: 250,
  },
  {
    name: 'Efso Burger',
    image: BurgerImage,
    content: '150 gr kasap Burger,Patates,Turşu',
    price: 250,
  },
  {
    name: 'Efso Burger',
    image: BurgerImage,
    content: '150 gr kasap Burger,Patates,Turşu',
    price: 250,
  },
  {
    name: 'Efso Burger',
    image: BurgerImage,
    content: '150 gr kasap Burger,Patates,Turşu',
    price: 250,
  },
  {
    name: 'Efso Burger',
    image: BurgerImage,
    content: '150 gr kasap Burger,Patates,Turşu',
    price: 250,
  },
  {
    name: 'Efso Burger',
    image: BurgerImage,
    content: '150 gr kasap Burger,Patates,Turşu',
    price: 250,
  },
  {
    name: 'Efso Burger',
    image: BurgerImage,
    content: '150 gr kasap Burger,Patates,Turşu',
    price: 250,
  },
  {
    name: 'Efso Burger',
    image: BurgerImage,
    content: '150 gr kasap Burger,Patates,Turşu',
    price: 250,
  },
  {
    name: 'Efso Burger',
    image: BurgerImage,
    content: '150 gr kasap Burger,Patates,Turşu',
    price: 250,
  },
  {
    name: 'Efso Burger',
    image: BurgerImage,
    content: '150 gr kasap Burger,Patates,Turşu',
    price: 250,
  },
];
